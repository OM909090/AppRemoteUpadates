const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DFZTZy-T.js","assets/index-B15_yNpL.js","assets/index-ClgMSiuk.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-B15_yNpL.js";const _=p("App",{web:()=>r(()=>import("./web-DFZTZy-T.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
