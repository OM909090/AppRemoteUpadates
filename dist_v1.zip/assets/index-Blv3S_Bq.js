const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CINQxESP.js","assets/index-B15_yNpL.js","assets/index-ClgMSiuk.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-B15_yNpL.js";const _=e("Browser",{web:()=>o(()=>import("./web-CINQxESP.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
